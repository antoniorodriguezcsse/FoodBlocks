package com.example.antonio.foodblocksapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import USDA.FoodData;

import static com.example.antonio.foodblocksapp.R.id.textViewFoodBlocks;

public class MyRecyclerViewAdapter extends
        RecyclerView.Adapter<MyRecyclerViewAdapter.ViewHolder> {

    private OnItemClickListener mClickListener;
    private ArrayList<FoodData> foodDataObjectsList;

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.mClickListener = listener;
    }

    // stores and recycles views as they are scrolled off screen
    public class ViewHolder extends RecyclerView.ViewHolder  implements View.OnClickListener{
        private TextView nameOfFood;
        private TextView servingSize;
        private TextView foodBlocks;


        public ViewHolder(final View itemView) {
            super(itemView);

            nameOfFood = itemView.findViewById(R.id.textViewNameOfFood);
            servingSize = itemView.findViewById(R.id.textViewServingSize);
            foodBlocks = itemView.findViewById(R.id.textViewFoodBlocks);

           // itemView.setOnClickListener(this);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Triggers click upwards to the adapter on click
                    if (mClickListener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            mClickListener.onItemClick(itemView, position);
                        }
                    }
                }
            });
        }

        @Override
        public void onClick(View view) {
            if (mClickListener != null) mClickListener.onItemClick(view, getAdapterPosition());
        }
    }


    // parent activity will implement this method to respond to click events
    public interface OnItemClickListener {
        void onItemClick(View view, int position);
    }

    public String getItem(int position) {
        return String.valueOf(foodDataObjectsList.get(position));
    }


    // data is passed into the constructor
    public MyRecyclerViewAdapter(ArrayList<FoodData> foodDataObjectsList) {
        this.foodDataObjectsList = foodDataObjectsList;
    }

    @NonNull
    public MyRecyclerViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        Context context;
        context = parent.getContext();

        LayoutInflater inflater;
        inflater = LayoutInflater.from(context);

        View foodListView;
        foodListView = inflater.inflate(R.layout.recyclerview_row, parent, false);
        return new ViewHolder(foodListView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
        FoodData foodData = foodDataObjectsList.get(position);
        TextView textViewNameOfFood, textViewServingSize, textViewFoodBlocks;

        textViewNameOfFood= viewHolder.nameOfFood;
        textViewNameOfFood.setText(foodData.getName());

        textViewServingSize = viewHolder.servingSize;
        textViewServingSize.setText("Serving size: " + foodData.getServingSize());

        textViewFoodBlocks = viewHolder.foodBlocks;
        textViewFoodBlocks.setText("Food Blocks: " + foodData.getFoodBlocks());
    }

    @Override
    public int getItemCount(){
        return foodDataObjectsList.size();
    }
}