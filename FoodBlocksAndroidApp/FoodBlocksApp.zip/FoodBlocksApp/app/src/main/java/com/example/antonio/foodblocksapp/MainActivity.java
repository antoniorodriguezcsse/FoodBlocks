package com.example.antonio.foodblocksapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;

import java.util.ArrayList;

import USDA.FoodData;
import USDA.SearchUSDA;


public class MainActivity extends AppCompatActivity {

    private TextView mTextMessage;
    Button btnHit;
    AutoCompleteTextView foodSearchTextView;
    MyRecyclerViewAdapter adapter;


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Toast.makeText(MainActivity.this, "clicked",
                    Toast.LENGTH_LONG).show();
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    Toast.makeText(MainActivity.this, "clicked",
                            Toast.LENGTH_LONG).show();
                    mTextMessage.setText(R.string.title_home);
                    return true;
                case R.id.navigation_settings:
                    mTextMessage.setText(R.string.title_settings);
                    Intent intent1 = new Intent(MainActivity.this, Settings.class);
                    startActivity(intent1);

                    return true;
//           /    case R.id.navigation_notifications:
//                    mTextMessage.setText(R.string.title_notifications);
//                    return true;
            }
            return false;
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final ArrayList<FoodData> diaryList = new ArrayList<>();
        foodSearchTextView = findViewById(R.id.foodSearchAutoCompleteTextView);

        final TextView recyclerViewText = findViewById(R.id.recylerViewText);
        final EditText foodBlocksText = findViewById(R.id.foodBlocks);

        // Search button
        final Button buttonSearch = findViewById(R.id.buttonSearch);
        buttonSearch.setOnClickListener(new View.OnClickListener() {

            // when the search button is clicked
            public void onClick(View v) {
                String foodToSearchFor = foodSearchTextView.getText().toString();

                if (foodToSearchFor.equals("")) {
                    Toast.makeText(MainActivity.this, "Enter a food",
                            Toast.LENGTH_LONG).show();
                }

                //if food to search for is not an empty string.
                else {
                    SearchUSDA searchUSDA = null;
                    try {
                        searchUSDA = new SearchUSDA(foodToSearchFor);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    assert searchUSDA != null;

                    //THis array is what is populates the recycleViewer when searching for food.
                    final ArrayList<FoodData> arrayOfFoodObjects = searchUSDA.getFoodObjects();

                    final RecyclerView foodListObjects = findViewById(R.id.recyclerView);

                    adapter = new MyRecyclerViewAdapter(arrayOfFoodObjects);

                    if (arrayOfFoodObjects.size() > 0) {
                        recyclerViewText.setText("Selected food to add to diary");
                    }
                    // When you click on an item in the recycleViewer
                    adapter.setOnItemClickListener(new MyRecyclerViewAdapter.OnItemClickListener() {
                        @Override
                        public void onItemClick(View view, final int position) {
                            if (recyclerViewText.getText().equals("Selected food to add to diary")) {
                                // pop up to notify user if they want to add the food to their diary
                                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                builder.setTitle("Confirm add food to diary");
                                builder.setMessage((arrayOfFoodObjects.get(position).getName() +
                                        "\n\n Food blocks:" +
                                        arrayOfFoodObjects.get(position).getFoodBlocks()));
                                builder.setCancelable(false);

                                //User clicked yes, they want to add food.
                                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        // add food to the diaryList
                                        diaryList.add(arrayOfFoodObjects.get(position));


                                        recyclerViewText.setText("Diary");
                                        Integer foodBlocks = Integer.valueOf(foodBlocksText.getText().toString());
                                        Log.i("TAG", "value of foodBlocks: " + foodBlocks);
                                        Integer foodToAdd = Integer.valueOf(arrayOfFoodObjects.get(position).getFoodBlocks());

                                        // Log.i("TAG", "value of textToSet: " + Integer.toString(foodBlocks - foodToAdd));
                                        foodBlocksText.setText(Integer.toString(foodBlocks - foodToAdd));

                                        arrayOfFoodObjects.clear();
                                        arrayOfFoodObjects.addAll(diaryList);
                                        adapter.notifyDataSetChanged();
                                    }
                                });

                                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        // Do nothing
                                    }
                                });

                                builder.show();
                            } else {
                                // pop up to notify user if they want to add the food to their diary
                                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                builder.setTitle("Confirm delete food from diary");
                                builder.setMessage((arrayOfFoodObjects.get(position).getName() +
                                        "\n\n Food blocks:" +
                                        arrayOfFoodObjects.get(position).getFoodBlocks()));
                                builder.setCancelable(false);

                                //User clicked yes, they want to add food.
                                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                        arrayOfFoodObjects.remove(position);
                                        diaryList.remove(position);
                                        adapter.notifyDataSetChanged();

                                        recyclerViewText.setText("Diary");
//                                        Integer foodBlocks = Integer.valueOf(foodBlocksText.getText().toString());
//
//                                        Integer foodToAdd;
//                                        Log.i("TAG", "This number: " + Integer.valueOf(arrayOfFoodObjects.get(position).getFoodBlocks()));
//                                        foodToAdd = Integer.valueOf(arrayOfFoodObjects.get(position).getFoodBlocks());
//
//                                        foodBlocksText.setText(String.format("%d", Integer.toString(foodBlocks + foodToAdd)));

                                        arrayOfFoodObjects.clear();
                                        arrayOfFoodObjects.addAll(diaryList);
                                        adapter.notifyDataSetChanged();
                                    }
                                });

                                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        // Do nothing
                                    }
                                });

                                builder.show();
                            }
                        }
                    });

                    foodListObjects.setAdapter(adapter);

                    foodListObjects.setLayoutManager(new LinearLayoutManager(MainActivity.this));

                    hideKeyboard(MainActivity.this);
                }
            }
        });
    }

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }

        assert imm != null;
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
}


