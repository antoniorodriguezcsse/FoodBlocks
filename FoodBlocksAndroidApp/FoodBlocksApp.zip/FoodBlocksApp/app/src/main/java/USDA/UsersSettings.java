package com.company;

public class UsersSettings {
    private Integer age;
    private Integer heightInInches;
    private Double weightInPounds;
    private String sex;
    private Double activityMultiplier;
    private Double TDEE;
    private Integer calorieGoal;

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Integer getHeightInInches() {
        return heightInInches;
    }

    public void setHeightInInches(Integer heightInInches) {
        this.heightInInches = heightInInches;
    }

    public Double getWeightInPounds() {
        return weightInPounds;
    }

    public void setWeightInPounds(Double weightInPounds) {
        this.weightInPounds = weightInPounds;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Double getActivityMultiplier() {
        return activityMultiplier;
    }

    public void setActivityMultiplier(Double activityMultiplier) {
        this.activityMultiplier = activityMultiplier;
    }

    public Double getTDEE() {

        Double BMR = 0.0;
        if(getSex().equals("m"))
        {
            //BMR = 66 + ( 6.2 × weight in pounds ) + ( 12.7 × height in inches ) – ( 6.76 × age in years )
            BMR = 66 + ((6.2 * getWeightInPounds()) + (12.7 * getHeightInInches())) - (6.76 * getAge());

            TDEE = BMR * getActivityMultiplier();
        }

        if(getSex().equals("f"))
        {
           // BMR = 655.1 + ( 4.35 × weight in pounds ) + ( 4.7 × height in inches ) - ( 4.7 × age in years )

        }

        return TDEE;
    }
/*
    public void setTDEE(Integer TDEE) {
        this.TDEE = TDEE;
    }
    */
    public Integer getCalorieGoal() {
        return calorieGoal;
    }

    public void setCalorieGoal(Integer calorieGoal) {
        this.calorieGoal = calorieGoal;
    }

}
