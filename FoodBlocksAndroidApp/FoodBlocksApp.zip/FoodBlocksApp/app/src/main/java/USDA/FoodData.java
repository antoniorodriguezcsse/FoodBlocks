package USDA;

import android.util.Log;

import java.math.RoundingMode;
import java.text.DecimalFormat;

public class FoodData {
    private String name;
    private String foodId;
    private String servingSize;

    private String gramsOfCarbs;
    private String gramsOfProtein;
    private String gramsOfFat;

    public void setFoodId(String foodId) {
        this.foodId = foodId;
    }

    public String getFoodId() {
        return foodId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGramsOfCarbs(String gramsOfcarbs) {
        if (gramsOfcarbs.equals("--") || gramsOfcarbs.isEmpty()) {
            this.gramsOfCarbs = "0.00";
        } else {
            this.gramsOfCarbs = gramsOfcarbs;
        }
    }

    public String getGramsOfCarbs() {
        return gramsOfCarbs;
    }

    public void setGramsOfProtein(String gramsOfProtein) {
        if (gramsOfProtein.equals("--")) {
            this.gramsOfProtein = "0.00";
        } else {
            this.gramsOfProtein = gramsOfProtein;
        }
    }

    public void setGramsOfFat(String gramsOfFat) {
        if (gramsOfFat.equals("--") ) {
            this.gramsOfFat = "0.00";
        } else {
            this.gramsOfFat = gramsOfFat;
        }
    }

    public String getCarbBlocks() {
        double d = (Double.parseDouble(gramsOfCarbs) * 4) / 40;
        return String.valueOf(d);

    }

    public String getProteinBlocks() {
        double d = (Double.parseDouble(gramsOfProtein) * 4) / 40;
        return String.valueOf(d);
    }

    public String getFatBlocks() {
        double d = ((Double.parseDouble(gramsOfFat) * 9) / 40);
        return String.valueOf(d);
    }

    public String getFoodBlocks() {

        double carbBlocks = Double.parseDouble(getCarbBlocks());
        double proteinBlocks = Double.parseDouble(getProteinBlocks());
        double fatBlocks = Double.parseDouble(getFatBlocks());


        int totalBlocks = (int) (carbBlocks + proteinBlocks + fatBlocks);
        return String.valueOf(totalBlocks);
    }

    public void setServingSize(String servingSize) {
        this.servingSize = servingSize;
    }

    public String getServingSize() {
        return this.servingSize;
    }
}
