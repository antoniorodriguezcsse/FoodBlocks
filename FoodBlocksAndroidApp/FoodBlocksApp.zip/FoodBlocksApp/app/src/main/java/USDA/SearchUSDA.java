package USDA;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class SearchUSDA {
    FoodData foodData = new FoodData();
    private String apiKey = "x5qM9v8PkjZrTf2cVSHzoK7y4GsSBgoQEmJsbwqV";
    private String type = "b";
    private String format = "json";
    private String nameOfFood;
    // private ArrayList<String> JSONFoodReportArray = new ArrayList<>();
    private ArrayList<String> idOfFo00ods = new ArrayList<>();
    private ArrayList<FoodData> listOfFoodObjects = new ArrayList<>();
    private ArrayList<String> JSONdataWithIDs = new ArrayList<>();
    private ArrayList<String> listOfDataBaseNumbers = new ArrayList<>();

    // constructor
    public SearchUSDA(String nameOfFoodToSearchFor) throws JSONException {

        //JSONdataWithIDs is an array were each element is one line of JSON
        // This will set the JSOnDataWithIDs array with the JSON data.
        setJSONdataWIthIDs(nameOfFoodToSearchFor);

        //This will parse the JSonDataWithIDs to extract the ID of the food
        setListOfDataBaseNumbersFromJSONdataWithIDs();

        //listOfFoodObjects is an array of objects that will store each food that has been returned
        // from the search. The object contains Food info, such as calories, proteins, etc..
        setListOfFoodObjects();
    }

    public ArrayList<FoodData> getFoodObjects() {
        return listOfFoodObjects;
    }

    // Sets the ArrayList(listOfFoodObjects) with foodObjects
    private void setListOfFoodObjects() throws JSONException {
        for (int i = 0; i < listOfFoodObjects.size(); i++) {
            setFoodObject(listOfFoodObjects.get(i).getFoodId(), listOfFoodObjects.get(i));
        }
    }

    // Sets One object for the food data.
    private void setFoodObject(final String foodID, FoodData foodData) throws JSONException {
        JSONObject json = null;

        final String myUrl = "https://api.nal.usda.gov/ndb/nutrients/?format=json&api_key=" +
                "x5qM9v8PkjZrTf2cVSHzoK7y4GsSBgoQEmJsbwqV" +
                "&nutrients=203&nutrients=205&nutrients=204&nutrients=208&nutrients=269&ndbno=" + foodID;

        HttpGetJSONRequest getRequest = new HttpGetJSONRequest();

        //Perform the doInBackground method, passing in our url
        try {
            json = getRequest.execute(myUrl).get();

        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

        //   FoodData foodData = new FoodData();//////////////////////////////////

        JSONObject report = null;
        if (json != null) {
            report = json.getJSONObject("report");
        }

        JSONArray foods = new JSONArray();
        assert report != null;
        foods = report.getJSONArray("foods");

        foodData.setName((String) foods.getJSONObject(0).get("name"));

        JSONArray nutrients = foods.getJSONObject(0).getJSONArray("nutrients");

        Object servingSize = null;
        servingSize = foods.getJSONObject(0).get("measure");
        if (servingSize.equals(null)) {
            foodData.setServingSize("0.00");
            foodData.setGramsOfCarbs("0.00");
            foodData.setGramsOfProtein("0.00");
            foodData.setGramsOfFat("0.00");
        } else {
            foodData.setServingSize((String) foods.getJSONObject(0).get("measure"));
        }

        if(nutrients.length() == 0)
        {
            foodData.setServingSize("0.00");
            foodData.setGramsOfCarbs("0.00");
            foodData.setGramsOfProtein("0.00");
            foodData.setGramsOfFat("0.00");
        }
        for (int i = 0; i < nutrients.length(); i++) {

            if (nutrients.getJSONObject(i).get("nutrient").equals("Carbohydrate, by difference")) {
               // Log.i("TAG", "Carbs: " + nutrients.getJSONObject(i).get("value").toString());
                foodData.setGramsOfCarbs(nutrients.getJSONObject(i).get("value").toString());
            //    Log.i("TAG", "Carbs:" + foodData.getCarbBlocks());
            }

            if (nutrients.getJSONObject(i).get("nutrient").equals("Protein")) {
           //     Log.i("TAG", "Protein: " + nutrients.getJSONObject(i).get("value").toString());
                foodData.setGramsOfProtein(nutrients.getJSONObject(i).get("value").toString());
          //      Log.i("TAG", "Protein: " + foodData.getProteinBlocks());
            }

            if (nutrients.getJSONObject(i).get("nutrient").equals("Total lipid (fat)")) {
           //     Log.i("TAG", "Fats: " + nutrients.getJSONObject(i).get("value").toString());
                foodData.setGramsOfFat(nutrients.getJSONObject(i).get("value").toString());
          //      Log.i("TAG", "fats: " + foodData.getProteinBlocks());
            }

//            if (nutrients.getJSONObject(i).get("nutrient").equals("Energy")) {
//                foodData.setCaloriesFor100Grams(nutrients.getJSONObject(i).get("gm").toString());
//            }
        }




     //   Log.i("TAG", foodData.getCarbBlocks());
//        Log.i("TAG", foodData.getProteinBlocks());
//        Log.i("TAG",foodData.getFatBlocks());


    }


    private void setJSONdataWIthIDs(String nameOfFood) {

        final String myUrl = "https://api.nal.usda.gov/ndb/search/?format=json&q=" +
                nameOfFood + "&sort=n&max=20&offset=0&api_key=x5qM9v8PkjZrTf2cVSHzoK7y4GsSBgoQEmJsbwqV";

        //String to place our result in
        HttpGetRequest getRequest = new HttpGetRequest();

        //Perform the doInBackground method, passing in our url
        try {
            JSONdataWithIDs = getRequest.execute(myUrl).get();

        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }

    private void setListOfDataBaseNumbersFromJSONdataWithIDs() {
        for (int i = 0; i < JSONdataWithIDs.size(); i++) {
            if (JSONdataWithIDs.get(i).contains("ndbno")) {
                FoodData foodData = new FoodData();
                String nutritinalDatabaseNumber = JSONdataWithIDs.get(i).replace("\"ndbno\": \"", "");

                nutritinalDatabaseNumber = nutritinalDatabaseNumber.replace("\",", "");
                nutritinalDatabaseNumber = nutritinalDatabaseNumber.replaceAll("\\s+", "");
                foodData.setFoodId(nutritinalDatabaseNumber);

                listOfFoodObjects.add(foodData);
            }
        }
    }
}
